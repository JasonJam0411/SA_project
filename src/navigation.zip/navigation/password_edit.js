import React, { Component } from 'react';
import { Container, Header, Content, Item, Input,
  Button,Text } from 'native-base';
import {StyleSheet,View} from'react-native';
import Icon from 'react-native-vector-icons/FontAwesome5';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';

import { useNavigation } from '@react-navigation/native';

class Password_edit extends Component{
  render() {
    const { navigation } = this.props;
    return (
      <Container>
        <Content>
          <View style={{flexDirection: 'row',backgroundColor:'#005AB5'}}>
          <Icon name="lock-open" color={'white'} size={33} style={styles.iconstyle}/>
          <Item rounded style={styles.shadowstyleinput}>
            <Input placeholder='請輸入您的 舊密碼'/>
          </Item>
          </View>
          <View
                    style={{
                      borderBottomColor: '#005AB5',
                      borderBottomWidth: 15
                    }}
                  />
          <View style={{flexDirection: 'row'}}>
          <Icon name="lock" color={'#005AB5'} size={40} style={styles.iconstyle}/>
          <Item rounded style={styles.shadowstyleinput}>
            <Input placeholder='請輸入您的 新密碼'/>
          </Item>
          </View>
          <View style={{flexDirection: 'row'}}>
          <Icon name="lock" color={'#005AB5'} size={40} style={styles.iconstyle}/>
          <Item rounded style={styles.shadowstyleinput}>
            <Input placeholder='新密碼確認'/>
          </Item>
          </View>
          <View style={{flexDirection: 'row',marginTop:30}}>
          {/* onPress={() => navigation.goBack()  確認修改成功跳頁用這句話 */}
              <Button rounded style={styles.botton1}>
                <Text style={styles.bottonText}>修改</Text>  
              </Button>
              <Button bordered rounded style={styles.botton2} onPress={() => navigation.goBack()}> 
                <Text style={styles.bottonText}>取消</Text>
              </Button>
          </View>
        </Content>
      </Container>
    );
    }
}
export default function(props) {
  const navigation = useNavigation();

  return <Password_edit {...props} navigation={navigation} />;
}
const styles = StyleSheet.create({
  shadowstyleinput:{
    backgroundColor:"white",
    elevation:9,
    marginTop:15,
    marginLeft:10,
    height:65,
    width:335

  },
  iconstyle:{
    marginTop:25,
    marginLeft:15
  },
  botton1:{
    marginLeft:90,
    width:100,
    height:55,
  },
  botton2:{
    marginLeft:35,
    width:100,
    height:55,
  },
  bottonText:{
    marginLeft:18,
    fontWeight:'bold',
    fontSize:15
  }
});