import * as React from 'react';
import { Component,useState, useEffect,useCallback  } from 'react';
import { List, Checkbox } from 'react-native-paper';
import { Image ,FlatList,StyleSheet,Linking, Button} from 'react-native';
import { Container, Header, Content, Card, CardItem, 
  Thumbnail, Text, Icon, Left, Body, View,Badge} from 'native-base';

import firestore from '@react-native-firebase/firestore';

function Institution1(){
    const ref = firestore().collection("Institution").doc("喜憨兒社會福利基金會");
    
    const [ loading, setLoading ] = useState(true);
    const [ todos, setTodos ] = useState([]);
    
    useEffect(() => {
      return ref.onSnapshot(documentSnapshot => {
        const list = [];
            const { group_purpose, service_purpose ,tel, address,
              donate_way,donate_account,donate_name,website,picture} = documentSnapshot.data();
            list.push(
            { 
              group_purpose,
              service_purpose,
              tel,
              address,
              donate_way,
              donate_account,
              donate_name,
              website,
              picture
            });
      
        setTodos(list);
    
        if (loading) {
          setLoading(false);
        }
      });
    }, []);

    const OpenURLButton = ({ url, children }) => {
      const handlePress = useCallback(async () => {
        // Checking if the link is supported for links with custom URL scheme.
        const supported = await Linking.canOpenURL(url);
    
        if (supported) {
          // Opening the link with some app, if the URL scheme is "http" the web link should be opened
          // by some browser in the mobile
          await Linking.openURL(url);
        } else {
          Alert.alert(`Don't know how to open this URL: ${url}`);
        }
      }, [url]);
    
      return <Button title={children} onPress={handlePress}/>;
    };

  return (
    <Container>
      <Content>
        
      <FlatList
        data={todos} renderItem={({ item }) => (
            
          
              <List.Section>
                <Image source={{uri: item.picture}} 
              style={{height: 175, width: 175, flex: 1,marginLeft:120,marginTop:10}}/>
              <List.Accordion
                theme={{ colors: { primary: '#F00078'}}}
                title="我們是什麼樣的團體 ?"
                left={props => <List.Icon {...props} icon="account-multiple"  />}
                style={styles.shadowstyleinput}
              >
                <Text style = {{fontSize: 15,marginTop:10}}>{item.group_purpose}</Text>
             
              </List.Accordion>

              <List.Accordion
              theme={{ colors: { primary: '#F00078' }}}
                title="我們在關心的人是誰 ?"
                left={props => <List.Icon {...props} icon="account-heart" />}
                style={styles.shadowstyleinput}
                
              >
                <Text style = {{fontSize: 15,marginTop:10}}>{item.service_purpose}</Text>
              </List.Accordion>
              <List.Accordion
              theme={{ colors: { primary: '#F00078' }}}
                title="基本資料"
                left={props => <List.Icon {...props} icon="file-document-outline" />}
                style={styles.shadowstyleinput}
              >
                <View style={{flexDirection: 'row',marginTop:10}}>
                  <Badge style={{ backgroundColor: '#FF0080' }}>
                  <Text style = {{fontSize: 15,fontWeight:"bold"}}>電話</Text>
                  </Badge>
                  <Text style = {{fontSize: 15}}>{"  "}{item.tel}</Text>
                </View>
                <View style={{flexDirection: 'row',marginTop:10}}>
                  <Badge style={{ backgroundColor: '#FF0080' }}>
                  <Text style = {{fontSize: 15,fontWeight:"bold"}}>地址</Text>
                  </Badge>
                  <Text style = {{fontSize: 15}}>{"  "}{item.address}</Text>
                </View>
              </List.Accordion>
              <List.Accordion
              theme={{ colors: { primary: '#F00078' }}}
                title="捐款資訊"
                left={props => <List.Icon {...props} icon="gesture-tap" />}
                style={styles.shadowstyleinput}
              >
                <View style={{flexDirection: 'row',marginTop:10}}>
                  <Badge style={{ backgroundColor: '#FF0080' }}>
                  <Text style = {{fontSize: 15,fontWeight:"bold"}}>捐款方式</Text>
                  </Badge>
                  <Text style = {{fontSize: 15}}>{"  "}{item.donate_way}</Text>
                </View>
                <View style={{flexDirection: 'row',marginTop:10}}>
                  <Badge style={{ backgroundColor: '#FF0080' }}>
                  <Text style = {{fontSize: 15,fontWeight:"bold"}}>郵政劃撥帳號</Text>
                  </Badge>
                  <Text style = {{fontSize: 15}}>{"  "}{item.donate_account}</Text>
                </View>
                <View style={{flexDirection: 'row',marginTop:10}}>
                  <Badge style={{ backgroundColor: '#FF0080' }}>
                  <Text style = {{fontSize: 15,fontWeight:"bold"}}>戶名</Text>
                  </Badge>
                  <Text style = {{fontSize: 15}}>{"  "}{item.donate_name}</Text>
                </View>
              </List.Accordion>
              <View style={{width:200,marginTop:45,marginLeft:110}}>
              <OpenURLButton url={item.website}>前往 官方網頁</OpenURLButton>
              </View>
            </List.Section>
          
          )}
      />
           
            
          
      </Content>
    </Container>
  );
}
export default Institution1;

const styles = StyleSheet.create({
  shadowstyleinput:{
    backgroundColor:"white",
    elevation:5,
    marginTop:5,
    height:65
  
  }
});

