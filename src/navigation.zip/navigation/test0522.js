import React, { Component,useState, useEffect } from "react";
import { View, Alert ,FlatList} from "react-native";
import {
  Container, Header,Title,
  Content,Icon,Card,CardItem,
  Text,
  Thumbnail,
  Left,
  Body,
  Right
} from "native-base";
import styles from "./styles";
import LottieView from 'lottie-react-native';
import auth from '@react-native-firebase/auth';
import { Badge, Avatar, Button, Dialog, Portal, Provider, TextInput, RadioButton } from 'react-native-paper';
import firebase from '@react-native-firebase/app';
import firestore from '@react-native-firebase/firestore';

import { useNavigation } from '@react-navigation/native';

class Lottie extends Component {

  componentDidMount() {
    this.animation.play();
    // Or set a specific startFrame and endFrame with:
    this.animation.play(2, 120);
  }
  render(){
    return(
        <LottieView
        ref={animation => {
            this.animation = animation;
        }}
        source={require('../animation/lf30_editor_2BAhfQ.json')}
        style={{ marginBottom: '-55%', width: '60%', marginLeft: '13%' }}
      />
    );
  }
}


function NHCardImage(){
  const user = firebase.auth().currentUser;
  const ref = firestore().collection("users").doc(user.uid);
  const [ loading, setLoading ] = useState(true);
  const [ todos, setTodos ] = useState([]);

      useEffect(() => {
        return ref.onSnapshot(documentSnapshot => {
          const list = [];
              const { address,phone,name,email} = documentSnapshot.data();
              list.push(
              { 
                address,
                phone,
                name,
                email
              });
        
          setTodos(list);
      
          if (loading) {
            setLoading(false);
          }
        });
      }, []);
      return (
        <Container style={styles.container_profile}>
          <Content padder>
            <View style={{ zIndex: 0 }}>
              <View style={{ zIndex: 3 }}>
               <Lottie></Lottie>
              </View>
              <View style={{ zIndex: 0 }}>
                <Card style={{ marginTop: '25%', height: 500 }}>
                  <CardItem>
                    <Left>
                      <Body>
  
                      </Body>
                    </Left>
                  </CardItem>
                  <View
                    style={{
                      borderBottomColor: '#FFC1E0',
                      borderBottomWidth: 13,
                      marginTop: '22%'
                    }}
                  />
                  <FlatList
                   data={todos} renderItem={({ item }) => (
                      <View style={{ marginTop: '-12%' }}>
                        <View style={{ alignItems: 'center' }}>
                          <CardItem>
                            <Badge size={60} style={{ fontWeight: 'bold' }}>{item.name}</Badge>
                          </CardItem>
                        </View>
                        <CardItem>
                          <Avatar.Icon size={40} icon="email" />
                          <Text style={{ fontSize: 18 }}>{"  "}{item.email}</Text>
                        </CardItem>
                        <CardItem>
                          <Avatar.Icon size={40} icon="home" />
                          <Text style={{ fontSize: 18 }}>{"  "}{item.address}</Text>
                        </CardItem>
                        <CardItem>
                          <Avatar.Icon size={40} icon="cellphone" />
                          <Text style={{ fontSize: 18 }}>{"  "}{item.phone}</Text>
                        </CardItem>
                      </View>
                )}
            />
                  <CardItem style={{ marginTop: '20%' }}>
                    <Left>
                      <Button color={"#FF0080"} icon="pencil" mode="contained" onPress={() => navigation.navigate('修改個人資料')}
                        style={{ width: 150, height: 40 }}>
                        修改個人資料
                      </Button>
                    </Left>
                    <Right>
                      <Button color={"#FF0080"} mode="outlined" onPress={() => 
                      navigation.navigate('Login')}
                        style={{ width: 100, height: 40 }}>
                        登出
                      </Button>
                    </Right>
                  </CardItem>
                </Card>
              </View>
            </View>
          </Content>
        </Container>
  
      );
    
}

export default function(props) {
  const navigation = useNavigation();

  return <NHCardImage {...props} navigation={navigation} />;
}
