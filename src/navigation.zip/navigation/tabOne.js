import * as React from 'react';
import { useState,useEffect } from 'react';
import { View, Image ,Alert,FlatList} from "react-native";
import { Container, Header, Item, Input, Icon,
         Button, Text ,Card,CardItem, Body, Content, 
         Left, Right, Thumbnail, Badge} from 'native-base';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import * as Progress from 'react-native-progress';

import firestore from '@react-native-firebase/firestore';

import styles from "./styles";

import Project_detail from './project.js';
import Donate_money from './donate.js';
import Institution1 from './institution1.js';
import Institution2 from './institution2.js';
import Institution3 from './institution3.js';
import Iconinfo from 'react-native-vector-icons/Entypo';

const logo = require("../../assets/give.png");


function HomeScreen({ navigation }) {
  const [ loading, setLoading ] = useState(true);
  const [ todos, setTodos ] = useState([]);
  const ref = firestore()
  .collection('Donate_Project').orderBy('last_days');
  
  useEffect(() => {
    return ref.onSnapshot(querySnapshot => {
      const list = [];
      querySnapshot.forEach(doc => {
        const { pro_group, pro_name ,last_days,
          target_money,now_money,picture} = doc.data();
        list.push({
          id: doc.id,
          pro_group,
          pro_name,
          last_days,
          target_money,
          now_money,
          picture
        });
      });
      setTodos(list);

      if (loading) {
        setLoading(false);
      }
    });
  }, []);

  return (
    <Container>
        <Header style={{ backgroundColor: "#ff3b7f" }} searchBar rounded >
          <Item>
            <Icon name="search" />
            <Input placeholder="搜尋機構名稱" />
            <Icon name="people" />
          </Item>
          <Button transparent>
            <Text>Search</Text>
          </Button>
        </Header>
		<Content padder style={{backgroundColor:'#FFECF5'}}>
        
		

         <FlatList
         data={todos}
         renderItem={({ item }) => (
           <Card style={styles.mb}>
          <CardItem>
          <Left>
            <Thumbnail source={logo} />
            <Body>
         <Text style={{fontWeight: 'bold'}}>{item.pro_name}</Text>
              <Text note>{item.pro_group}</Text>
            </Body>
          </Left>
          <Iconinfo name="info-with-circle" color={'#005AB5'} size={30} 
          button onPress={() => navigation.navigate(item.pro_group)}/>
        </CardItem>

        <CardItem cardBody button onPress={() =>navigation.navigate(item.pro_name)}>
          <Image
            style={{
              resizeMode: "cover",
              width: null,
              height: 200,
              flex: 1
            }}
            source={{uri:item.picture}}
          />
        </CardItem>

        <CardItem style={{ paddingVertical: 0 }} button onPress={() =>navigation.navigate(item.pro_name)}>
          <Left>
            <Button transparent>
            <Progress.Bar progress={(item.now_money/item.target_money)} width={180} height={12} color={'#ff0080'}/>
            <Text style={{fontWeight: 'bold',color: '#FF0080'}}>
              已達 {Math.round((item.now_money/item.target_money)*100)}%</Text>
            </Button>
            
          </Left>
         
          <Right>
          {item.last_days <=30 ? 
          <Badge style={{ backgroundColor: '#5E005E' }}>
          <Text style={{ color: 'white'}}>剩餘 {item.last_days} 天</Text>
         </Badge>:
         <Badge style={{ backgroundColor: '#F00078' }}>
         <Text style={{ color: 'white'}}>剩餘 {item.last_days} 天</Text>
        </Badge>}
            
          </Right>
        </CardItem>

        </Card>

         )} />
         

		
        </Content>
      </Container>

  );
}

const Stack = createStackNavigator();

function App() {
	
  return (
	  <Stack.Navigator>
        <Stack.Screen name="D" component={HomeScreen} options={{headerShown: false}}  />
        <Stack.Screen name="偏鄉兒的希望晚餐" component={Project_detail} />
        <Stack.Screen name="捐款-偏鄉兒的希望晚餐" component={Donate_money} />
        <Stack.Screen name="社團法人中華民國肯愛社會服務協會" component={Institution1} />
        <Stack.Screen name="喜憨兒社會福利基金會" component={Institution2} />
        <Stack.Screen name="財團法人伊甸社會福利基金會" component={Institution3} />
      </Stack.Navigator>

    
   
  );
}

export default App;
