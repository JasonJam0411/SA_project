import React, { Component, useState } from 'react';

import {
  StyleSheet,
  View,
  ImageBackground,
  Image
} from 'react-native';
import { Picker, Form, Label, Item, Container, Header, Content, Card,
   CardItem, Thumbnail, Text, Button, Icon, Left, Body, Right,Title,Input } from 'native-base';
import { ProgressSteps, ProgressStep } from 'react-native-progress-steps';
import { TextInput } from 'react-native-paper';
import firestore from '@react-native-firebase/firestore';


const styles = StyleSheet.create({
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',

  },
  mysize:{
  fontSize:20,

  },
  nopadding:{
    includeFontPadding: false,
    textAlignVertical: 'center',
    fontSize:17,
    marginTop: 20,
    marginLeft: 10

  },
  button: {
    margin: 20,
    padding: 10,
    paddingLeft: 20,
    paddingRight: 20,
    backgroundColor: '#406E9F',
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
  }, 
  creditcard:{
      
      backgroundColor:'#F0F0F0',
      width:70,
      height:35
      
  },
  myspace:{
      fontSize: 25,
      width: 25,
      textAlign: 'center'
  }

});

function donate() {
    const [ todo, setTodo ] = useState('');
    const ref = firestore().collection('donate');
  
    
    
}
export default class Donate_money extends Component {
    state = {
    text: ''
  };
 
  render() {
      async function addTodo() {
        await donate.ref.add({
        title: donate.todo,
        complete: false,
        });
        donate.setTodo('');
      }
 
    return (
        
    <View style={{flex:1}}>

      <Container >
         
        <Content >

          <Card>

            
         <ProgressSteps completedProgressBarColor = "#ff3b7f" activeStepIconBorderColor = "#ff3b7f" activeLabelColor = "#ff3b7f" completedStepIconColor = "#ff3b7f">
            <ProgressStep label="填寫個人資訊" nextBtnText="下一步">
            <Form style={{width: '90%', marginLeft:'5%'}}>
              
               
        {/* <Button onPress={() => addTodo()}><Text>Add TODO</Text></Button> */}
                 <TextInput
                    label='姓名'
                    
                    mode = 'outlined'
                    style = {{marginTop: 20}}
                    value={donate.todo} onChangeText={donate.setTodo}
                  />
        
                 <TextInput
                    label='捐款金額'
                    value={this.state.text}
                    onChangeText={text => this.setState({ text })}
                    mode = 'outlined'
                    style = {{marginTop: 10}}
                  />
                 <TextInput
                    label='手機號碼'
                    value={this.state.text}
                    onChangeText={text => this.setState({ text })}
                    mode = 'outlined'
                    style = {{marginTop: 10}}
                  />
                 <TextInput
                    label='市話'
                    value={this.state.text}
                    onChangeText={text => this.setState({ text })}
                    mode = 'outlined'
                    style = {{marginTop: 10}}
                  />

                 <TextInput
                    label='E-mail'
                    value={this.state.text}
                    onChangeText={text => this.setState({ text })}
                    mode = 'outlined'
                    style = {{marginTop: 10}}
                  />
               
                 
    
              
            </Form>
           </ProgressStep>
            
           <ProgressStep label="填寫信用卡卡號" nextBtnText="下一步" previousBtnText="上一步">
              <TextInput
                    label='100'
                    value={this.state.text}
                    onChangeText={text => this.setState({ text })}
                    mode = 'outlined'
                    style = {{marginTop: 20}}
                    disabled
                  />
              <TextInput
                    label='持卡人姓名'
                    value={this.state.text}
                    onChangeText={text => this.setState({ text })}
                    mode = 'outlined'
                    style = {{marginTop: 10}}
            />
             <View style={{flexDirection:'row'}}>
                  <Text style={styles.nopadding}>信用卡卡號:</Text>
              </View>
            
            
             
              <Body style={{flexDirection:'row',alignItems:'flex-start', marginTop: 20}}>
                 <TextInput  maxLength={4} style={styles.creditcard} />
                 <Text style={styles.myspace} >-</Text>
                 <TextInput  maxLength={4} style={styles.creditcard} />
                 <Text style={styles.myspace} >-</Text>
                 <TextInput  maxLength={4} style={styles.creditcard} />
                 <Text style={styles.myspace} >-</Text>
                 <TextInput  maxLength={4} style={styles.creditcard} />
               </Body>
            
                <View style={{flexDirection:'row'}}>
                  <Text style={styles.nopadding}>信用卡安全碼:</Text>
              </View>
            
            
             
              <Body style={{flexDirection:'row',alignItems:'flex-start', marginTop: 20, marginLeft: -280}}>
                 <TextInput  maxLength={4} style={styles.creditcard} />

               </Body>
                <View style={{flexDirection:'row'}}>
                  <Text style={styles.nopadding}>信用卡有效期限(月/年):</Text>
              </View>
            
            
             
              <Body style={{flexDirection:'row',alignItems:'flex-start', marginTop: 20, marginLeft: -180}}>
                 <TextInput  maxLength={2} style={styles.creditcard} />
                 <Text style={styles.myspace}>/</Text>
                 <TextInput  maxLength={2} style={styles.creditcard} />
               </Body>
                 
           </ProgressStep>
            <ProgressStep label="確認資料" previousBtnText="上一步" nextBtnText="確認">
              <TextInput
                    label='姓名'
                    value={this.state.text}
                    onChangeText={text => this.setState({ text })}
                    mode = 'outlined'
                    style = {{marginTop: 20}}
                    disabled
                  />
                 <TextInput
                    label='捐款金額(ex:100)'
                    value={this.state.text}
                    onChangeText={text => this.setState({ text })}
                    mode = 'outlined'
                    style = {{marginTop: 10}}
                    disabled
                  />
                 <TextInput
                    label='手機'
                    value={this.state.text}
                    onChangeText={text => this.setState({ text })}
                    mode = 'outlined'
                    style = {{marginTop: 10}}
                    disabled
                  />
                 <TextInput
                    label='電話'
                    value={this.state.text}
                    onChangeText={text => this.setState({ text })}
                    mode = 'outlined'
                    style = {{marginTop: 10}}
                    disabled
                  />

                 <TextInput
                    label='Email'
                    value={this.state.text}
                    onChangeText={text => this.setState({ text })}
                    mode = 'outlined'
                    style = {{marginTop: 10}}
                    disabled
                  />
           </ProgressStep>
            <ProgressStep label="填寫完成" previousBtnText="上一步" finishBtnText="完成">
              
           </ProgressStep>
           </ProgressSteps>
        
           
          </Card>
        </Content>

      </Container>
    </View>

    );
  }
}