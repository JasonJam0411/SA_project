import React, { Component } from 'react';
import { Container, Header, Content, Card, CardItem, 
  Text, Icon, Title, Right, Body, Button, Item, Label, 
  Input, Form} from 'native-base';
import {StyleSheet,View,Alert} from 'react-native';
import LottieView from 'lottie-react-native';

import TabsExample from './index.js';
import Todos from './register.js';
import NHCardImage from './tabThree.js';
import Profile_edit from './profile_edit.js';
import Password_edit from './password_edit.js';

import auth from '@react-native-firebase/auth';

import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

class CardListExample extends Component {
    componentDidMount() {
        this.animation.play();
        // Or set a specific startFrame and endFrame with:
        this.animation.play(2, 240);
      }

      constructor() {
        super();
        this.state = { 
          email: '', 
          password: '',
          isLoading: false
        }
      }
    
      updateInputVal = (val, prop) => {
        const state = this.state;
        state[prop] = val;
        this.setState(state);
      }
    
      userLogin = () => {
        if(this.state.email === '' || this.state.password === '') {
          Alert.alert('請輸入帳號與密碼!')
        } else {
          this.setState({
            isLoading: true,
          })
          auth()
          .signInWithEmailAndPassword(this.state.email, this.state.password)
          .then((res) => {
            console.log(res)
            console.log('User logged-in successfully!')
            this.setState({
              isLoading: false,
              email: '', 
              password: ''
            })
            this.props.navigation.navigate('index')
          })
          .catch((error) => {Alert.alert('登入失敗!帳號或密碼錯誤!')
          });
        }
      }
    
  render() {
    return (
        <View style={styles.container}>
      <Container>
        <Content style={{backgroundColor:'#FFECF5'}}>
        <LottieView
        ref={animation => {
          this.animation = animation;
        }}
        source={require('../animation/money_logo_large.json')}
        style={{marginBottom: '-63%',width:'70%',marginLeft:'10%'}}
      />
        <Form style={styles.input}>
          <Item rounded style={styles.shadowstyleinput}>
              <Input 
              placeholder='帳號'
              value={this.state.email}
              onChangeText={(val) => this.updateInputVal(val, 'email')}/>
                </Item>
          
          <Item rounded style={styles.shadowstyleinput}>
              <Input 
              placeholder='密碼'
              value={this.state.password}
              onChangeText={(val) => this.updateInputVal(val, 'password')}
              secureTextEntry={true}/>
                </Item>
        </Form>

        <View style={{flexDirection: 'column'}}>
        <View style={{alignItems: 'center'}}>
        <Button onPress={() => this.userLogin()}  info style={styles.buttoncolor}>
            <Text style={styles.word}>{"                      "}登入</Text>
        </Button>
        </View>
        <View style={{alignItems: 'center'}}>
        <Text style={{fontSize: 20,margin: '5%',color:'#600030'}}>----------其他登入方法----------</Text>
        </View>
        <View style={{alignItems: 'center'}}>
        <Button onPress={() => alert("正在登入Google帳號")}  info style={{marginTop: '5%',backgroundColor: '#FF3333',width:'68%'}}>
          <Icon active name="logo-google" />
          <Text>Google</Text>
        </Button>
        </View>
        <View style={{alignItems: 'center'}}>
        <Button onPress={() => alert("正在登入Facebook帳號")}  info style={{marginTop: '5%',backgroundColor: '#234D82',width:'68%'}}>
          <Icon active name="logo-facebook" />
          <Text>Facebook</Text>
        </Button>
        </View>

        <View style={{alignItems: 'center'}}>
          <Button onPress={() => this.props.navigation.navigate('register')}  transparent>
            <Text style={styles.word2}>還沒有帳號?</Text>
            <Text style={styles.word3}>點此註冊</Text>
          </Button>
          </View>
          </View>
        </Content>
      </Container>
      </View>
    );
  }
}

const Stack = createStackNavigator();

export default function UserLogin() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Login" component={CardListExample} options={{headerShown: false}}/>
        <Stack.Screen name="index" component={TabsExample} options={{headerShown: false}}/>
        <Stack.Screen name="register" component={Todos} options={{headerShown: false}}/>
        <Stack.Screen name="Profile" component={NHCardImage} options={{headerShown: false}}/>
        <Stack.Screen name="修改個人資料" component={Profile_edit}/>
        <Stack.Screen name="修改個人密碼" component={Password_edit}/>
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',

  },
  word: {
    fontSize: 20,
    textAlign: 'center',
    fontWeight:'bold'
  },
  word2: {
    fontSize: 16,
    textAlign: 'center',
    margin: '10%',
    color:'black'

  },
  word3: {
    fontSize: 16,
    textAlign: 'center',
    color:'#46A3FF',
    fontWeight:'bold'

  },
  buttoncolor: {
    textAlign: 'center',
    backgroundColor: '#ff3b7f',
    elevation:20,
    marginTop: '5%',
    width:'68%',
  },
  input:{
      marginLeft:30,
      marginTop: '60%',
      width:350
  },
  shadowstyleinput:{
    backgroundColor:"white",
    elevation:9,
    marginTop:20,
    height:65

  }
});