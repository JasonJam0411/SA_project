import React, { Component } from 'react';
import { Container, Header, Content, Item, Input,
  Button,Text } from 'native-base';
import {StyleSheet,View} from'react-native';
import Icon from 'react-native-vector-icons/FontAwesome5';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';
import firestore from '@react-native-firebase/firestore';
import { useNavigation } from '@react-navigation/native';
import auth from '@react-native-firebase/auth';
import firebase from '@react-native-firebase/app';
class Profile_edit extends Component{
  
  constructor() {
    super();
    
  this.state = {
    email: '',
    phone: '',
    address:'',
    password:'',
    userName: '',
    userPhone: '',
    userAddress: '',
    isLoading: true
  };
}
componentDidMount() {
  firestore()
      .collection('users')
      .doc(firebase.auth().currentUser.uid)
      .get().then(documentSnapshot => {
        this.setState(
          {
          email : documentSnapshot.get('email'),
          address : documentSnapshot.get('address'),
          phone :documentSnapshot.get('phone'),
          }
        )
      })
}

 



inputValueUpdate = (val, prop) => {
  const state = this.state;
  state[prop] = val;
  this.setState(state);
}


updateUser = () => {
  const { navigation } = this.props;
  let userPassword="";
  firestore()
      .collection('users')
      .doc(firebase.auth().currentUser.uid)
      .get().then(documentSnapshot => {
        userPassword = documentSnapshot.get('password');
        if(userPassword == this.state.password){
          this.setState({
            isLoading: true,
          });
          firestore()
          .collection('users')
          .doc(firebase.auth().currentUser.uid)
          .update({   
              phone : this.state.phone,
              email: this.state.email,
              address: this.state.address,
          }).then(() =>{
            if(firebase.auth().currentUser.updateEmail(this.state.email)){
                alert('修改完成 系統將為你導入')
                navigation.goBack()
                this.setState({password: ""});
            }
            else{
              alert('信箱修改失敗');
            }
          });
        }
        else
            {
              alert('修改失敗 密碼錯誤');
             }   
      });

  
}
  

  render() {
    
    
    const { navigation } = this.props;
    
    return (
      <Container>
        <Content>
          <View style={{flexDirection: 'row'}}>
          <Icon name="envelope" color={'#005AB5'} size={40} style={styles.iconstyle}/>
          <Item rounded style={styles.shadowstyleinput}>
            <Input placeholder='Email' value={this.state.email}
              onChangeText={(val) => this.inputValueUpdate(val, 'email')}/>
          </Item>
          </View>
          <View style={{flexDirection: 'row'}}>
          <Icon name="home" color={'#005AB5'} size={35} style={styles.iconstyle}/>
          <Item rounded style={styles.shadowstyleinput}>
            <Input placeholder='地址'value={this.state.address}
              onChangeText={(val) => this.inputValueUpdate(val, 'address')}/>
          </Item>
          </View>
          <View style={{flexDirection: 'row'}}>
          <Icon2 name="cellphone" color={'#005AB5'} size={40} style={styles.iconstyle}/>
          <Item rounded style={styles.shadowstyleinput}>
            <Input placeholder='手機'value={this.state.phone}
              onChangeText={(val) => this.inputValueUpdate(val, 'phone')}/>
          </Item>
          </View>
          <View style={{flexDirection: 'row'}}>
          <Icon name="lock" color={'#005AB5'} size={40} style={styles.iconstyle}/>
          <Item rounded style={styles.shadowstyleinput}>
            <Input placeholder='輸入密碼確認' value={this.state.password}
            onChangeText={(val) => this.inputValueUpdate(val, 'password')}
              />
          </Item>
          </View>
          <View style={{flexDirection: 'row',marginTop:30}}>
          {/* onPress={() => navigation.navigate('Profile')  確認修改成功跳頁用這句話 */}
              <Button rounded style={styles.botton1}>
                <Text style={styles.bottonText} onPress={() => this.updateUser()}>修改</Text>  
              </Button>
              <Button bordered rounded style={styles.botton2} onPress={() => navigation.goBack()}> 
                <Text style={styles.bottonText}>取消</Text>
              </Button>
          </View>
        </Content>
      </Container>
    );
    }
}
export default function(props) {
   const navigation = useNavigation();
   //console.log("n:"+navigation);
   //

  return <Profile_edit {...props} navigation={navigation} />;
}
const styles = StyleSheet.create({
  shadowstyleinput:{
    backgroundColor:"white",
    elevation:9,
    marginTop:15,
    marginLeft:10,
    height:65,
    width:335

  },
  iconstyle:{
    marginTop:25,
    marginLeft:15
  },
  botton1:{
    marginLeft:90,
    width:100,
    height:55,
  },
  botton2:{
    marginLeft:35,
    width:100,
    height:55,
  },
  bottonText:{
    marginLeft:18,
    fontWeight:'bold',
    fontSize:15
  }
});