import React, { useState } from 'react';
import firebase from '@react-native-firebase/app';
import auth from "@react-native-firebase/auth";
import { Text,StyleSheet,Alert } from 'react-native';
import firestore from '@react-native-firebase/firestore';
import { Container, Header, Content, Title, Left, Right, Body, 
  Button, Item, Label, Input, Form} from 'native-base';

function Todos({ navigation }) {
  const [  loading, setLoading ] = useState(true);
  const [  Name, setName] = useState('');
  const [  AccountName, setAccountName] = useState('');
  const [  Password, setPassword] = useState('');
  const [  CheckPassword, setCheckPassword] = useState('');
  const [  Email, setEmail] = useState('');
  const [  Address, setAddress] = useState('');
  const [  Phone, setPhone] = useState('');

  const ref = firestore().collection('users');

  async function addTodo()
  {
    if(Name == ''){Alert.alert('請輸入姓名');}
    else if(AccountName == ''){Alert.alert('請輸入帳號名稱');}
    else if(Password == ''){Alert.alert('請輸入密碼');}
    else if(CheckPassword == ''){Alert.alert('請輸入確認密碼');}
    else if(Email == ''){Alert.alert('請輸入Email');}
    else if(Address == ''){Alert.alert('請輸入地址');}
    else if(Phone == ''){Alert.alert('請輸入電話');}
    else
    {
      if(Password == CheckPassword)
      {
        firebase.auth().createUserWithEmailAndPassword(Email, Password).then(cred =>
        {
          setName('');
          setAccountName('');
          setPassword('');
          setCheckPassword('');
          setEmail('');
          setAddress('');
          setPhone('');
          return firestore().collection("users").doc(cred.user.uid).set({
            name : Name,
            accountName : AccountName,
            password : Password,
            checkPassword : CheckPassword,
            email : Email,
            address : Address,
            phone : Phone,
          });
        }).then(() =>{
          Alert.alert('註冊完成 系統將為你導入')}).then(()=>{navigation.popToTop()}).catch((error) => {
            var errorMessage = error.message;
            if(errorMessage.indexOf('email address is already in use by another') !== -1)
            {
              alert(Email + '，註冊失敗!此Email已被註冊');
            }
            else
            {
              alert(Email + '，註冊失敗!' + errorMessage);
            }
          });
      }
      else
      {
        Alert.alert(Email + '，註冊失敗!密碼與確認密碼不同');
      }
    }
  }

    return (
      <Container>
        <Header style={{backgroundColor: "#ff3b7f"}}>
         <Left>
          <Button hasText transparent>
           <Text onPress={() => navigation.goBack()} style={{fontWeight:'bold',color:'#600030'}}>Back</Text>
          </Button>
         </Left>
         <Body>
          <Title >註冊新帳號</Title>
         </Body>
         <Right>
         </Right>
        </Header>

        <Content style={{marginTop:'5%',backgroundColor:'#FFECF5'}}>
        <Form style={{width: '90%', marginLeft:'5%'}}>
          <Item rounded style={styles.shadowstyleinput}>
            <Input 
            placeholder=' 姓名'
            value={Name} onChangeText={setName}/>
          </Item>
          <Item rounded style={styles.shadowstyleinput}>
            <Input 
            placeholder=' 帳號名稱'
            value={AccountName} onChangeText={setAccountName}/>
          </Item>
          <Item rounded style={styles.shadowstyleinput}>
            <Input 
            placeholder=' 密碼'
            secureTextEntry={true} value={Password} onChangeText={setPassword}/>
          </Item>
          <Item rounded style={styles.shadowstyleinput}>
            <Input 
            placeholder=' 確認密碼'
            secureTextEntry={true} value={CheckPassword} onChangeText={setCheckPassword}/>
          </Item>
          <Item rounded style={styles.shadowstyleinput}>
            <Input 
            placeholder=' Email'
            value={Email} onChangeText={setEmail}/>
          </Item>
          <Item rounded style={styles.shadowstyleinput}>
            <Input 
            placeholder=' 收件地址'
            value={Address} onChangeText={setAddress}/>
          </Item>
          <Item rounded style={styles.shadowstyleinput}>
            <Input 
            placeholder=' 電話'
            value={Phone} onChangeText={setPhone}/>
          </Item>
        </Form>
        <Button style={{alignItems:'center', justifyContent:'center', width: '80%', marginTop:'13%', marginLeft:'10%', backgroundColor: "#ff3b7f"}} onPress={() => addTodo()} block info>
          <Text style={{textAlign: 'center', fontSize: 24, color:"#ffffff",fontWeight:'bold'}}>註 冊</Text>
        </Button>
        </Content>
      </Container>
    );
  }
export default Todos;

const styles = StyleSheet.create({
  shadowstyleinput:{
    backgroundColor:"white",
    elevation:5,
    marginTop:15,
    height:60

  }
});