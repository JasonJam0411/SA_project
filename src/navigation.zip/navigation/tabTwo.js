import React, { useState, useEffect } from 'react';
import { List, Checkbox } from 'react-native-paper';
import firebase from '@react-native-firebase/app';
import auth from "@react-native-firebase/auth";
import {FlatList,Container,Text,View,Content} from 'react-native';
import firestore from '@react-native-firebase/firestore';
import styles from './styles.js';

class MyComponent extends React.Component {
  state = {
    expanded: true
  }

  _handlePress = () =>
    this.setState({
      expanded: !this.state.expanded
    });
  }
  
function RcpList() {
  var user = firebase.auth().currentUser;
  const ref = firestore().collection("users").doc(user.uid).collection("donate_rcp");
  
  const [ loading, setLoading ] = useState(true);
  const [ todos, setTodos ] = useState([]);
  
  useEffect(() => {
    return ref.onSnapshot(querySnapshot => {
      const list = [];
      querySnapshot.forEach(doc => {
          const { project_name, rcpID ,pro_group, donate_date, donate_way,money} = doc.data();
          list.push(
          { id: doc.id,
            project_name,
            rcpID,
            pro_group,
            donate_date,
            donate_way,
            money
          });
      });
      setTodos(list);
  
      if (loading) {
        setLoading(false);
      }
    });
  }, []);
  
  return (
    
      <FlatList
        data={todos} renderItem={({ item }) => (
          <List.Accordion title={item.project_name} 
          left={props => <List.Icon {...props} icon="heart" color={'#FF0080'} />}>
            <Text style = {{fontSize: 18, marginLeft:'2%', marginTop: '0%'}}>收據編號: {item.rcpID}</Text>
            <Text style = {{fontSize: 18, marginLeft:'2%', marginTop: '5%'}}>公益團體: {item.pro_group}</Text>
            <Text style = {{fontSize: 18, marginLeft:'2%', marginTop: '5%'}}>捐贈日期: {item.donate_date}</Text>
            <Text style = {{fontSize: 18, marginLeft:'2%', marginTop: '5%'}}>捐款方式: {item.donate_way}</Text>
            <Text style = {{fontSize: 18, marginLeft:'2%', marginTop: '5%'}}>捐款金額: {item.money}</Text>
          </List.Accordion>
        )}
      />
    );
  }
  export default RcpList;