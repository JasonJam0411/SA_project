import React, { useState,useEffect } from 'react';
import { FlatList, ScrollView, ART, View, Image, StyleSheet } from 'react-native';
import { ListItem, List, Badge, Tab, Tabs, Container, Header, Content, 
  Card, CardItem, Thumbnail, Text, Button, Icon, Left, Body, Right } from 'native-base';
import * as Progress from 'react-native-progress';
import ExpandableText from 'rn-expandable-text'
import firestore from '@react-native-firebase/firestore';
import Swiper from 'react-native-swiper';



function Project_detail({ navigation }) {
    
  const [ loading, setLoading ] = useState(true);
  const [ todos, setTodos ] = useState([]);
  const ref = firestore()
  .collection("Donate_Project").where('pro_name', '==', '偏鄉兒的希望晚餐');
  

  useEffect(() => {
    return ref.onSnapshot(querySnapshot => {
    const list = [];
    querySnapshot.forEach(doc => {
      const { pro_group, pro_name, pro_date, target_money, now_money, pro_content } = doc.data();
      list.push({
        id: doc.id,
        pro_group,
        pro_name,
        pro_date,
        target_money,
        now_money,
        pro_content,
      });
      var NewText = pro_content.replace("//n", "/n");
    });
    console.log(list);
    setTodos(list);
    if (loading) {
      setLoading(false);
    }
  });
  }, []);

  return (
 
    <Container>  
        <Content padder>
          <Card>
            
            <CardItem cardBody>
              
              <Swiper style={{height: 250, width: null}} showsButtons={true}>
                <View >
                  <Image  style={{height: 200, width: null}} source={require("../../assets/project02.jpg")}/>
                </View>
                <View >
                  <Image style={{height: 200, width: null}} source={require("../../assets/project02_1.jpg")} />
                </View>
              
              </Swiper>
            </CardItem>
            <CardItem bordered>
              <Body>
                    <View style={{flexDirection: 'row'}}>
                <FlatList 
                    
                    data={todos}
                    keyExtractor={(item) => item.id}
                    renderItem={({ item }) => (
                      <View style={{flexDirection: 'column'}}>
               <List>
                <View style={{flexDirection: 'row'}}>
                <ListItem>
                <Badge style={{ backgroundColor: '#820041' }}>
                <Text>目標金額</Text>
                </Badge>
                <Text>{"　"}{item.target_money}</Text>
                </ListItem>
                </View>
                <View style={{flexDirection: 'row'}}>
                <ListItem>
                <Badge style={{ backgroundColor: '#D9006C' }}>
                <Text>已捐金額</Text>
                </Badge>
                <Text>{"　"}{item.now_money}</Text>
                </ListItem>
                </View>
                <View style={{flexDirection: 'row'}}>
                <ListItem> 
                <Badge style={{ backgroundColor: '#FF0080' }}>
                <Text>尚缺金額</Text>
                </Badge>
                <Text>{"　"}{item.target_money - item.now_money}</Text>
                </ListItem>
                </View>
                </List>
                </View>
                  )}
                />

                <FlatList 
                    
                    data={todos}
                    keyExtractor={(item) => item.id}
                    renderItem={({ item }) => (
                        <Right>
                
                          <Progress.Circle size={150} 
                                           progress={(item.now_money/item.target_money)} 
                                           showsText={true} 
                                           thickness={15}
                                           color={'#ff0080'} 
                                           formatText={() => {
                                               return `${Math.round((item.now_money/item.target_money)*100)}%`
                           }}/>
                    </Right>
                  )}
                />
                </View>


                  <FlatList 
                    
                    data={todos}
                    keyExtractor={(item) => item.id}
                    renderItem={({ item }) => (
                      
                         <ExpandableText
                            numberOfLines={3}
                            unexpandView={() => (<Image source={require('../../assets/arraw_up.png')} style={{marginLeft: 300,height:50,width:50}}/>)}
                            expandView={() => (<Image source={require('../../assets/arraw_down.png')} style={{marginLeft: 300,height:50,width:50}}/>)}
                          >
                                {item.pro_content.replace(/ /g,"\n")}
                         </ExpandableText>
                      
                  )}
                />                    
                    
                
                
                
              </Body>
                
            </CardItem>
            <CardItem footer bordered>
              <Button
                style={styles.buttonColor}
                onPress={() => navigation.navigate('捐款-偏鄉兒的希望晚餐')}
              >
                  <Text> 立即捐款 </Text>
            </Button>
            </CardItem>
          </Card>
        </Content>
      </Container>
  );
}

export default Project_detail;

const styles = StyleSheet.create({
   
   Text: {
    marginLeft: 200,
    color: "#000000",
    
},
    buttonColor: {
    backgroundColor: "#ff3b7f",
    marginLeft: 130
},
    Text2: {
        fontSize: 18,
        color: "#000000",

},
    arrow_down: {
        marginTop: 10,
        marginBottom: 5,
        marginLeft: 'auto',
        marginRight: 'auto',
        width: 10,
        height: 10,
        borderRightWidth: 2,
        borderBottomWidth: 2,
        borderColor: '#7c91a5',
        transform: [{ rotate: '45deg' }],
},
    arrow_up: {
        marginTop: 10,
        marginBottom: 5,
        marginLeft: 'auto',
        marginRight: 'auto',
        width: 10,
        height: 10,
        borderRightWidth: 2,
        borderBottomWidth: 2,
        borderColor: '#b07dbf',
        transform: [{ rotate: '-135deg' }],
}


  
});


