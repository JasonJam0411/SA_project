export default {
  container: {
    backgroundColor: "#FFF"
  },
  container_profile:{
    backgroundColor:"#BF0060"
  },
  card_profile:{
    marginTop:'10%'
  },
  text: {
    alignSelf: "center",
    marginBottom: 7
  },
  mb: {
    marginBottom: 15
  },
  shadowstyle:{
    backgroundColor:"rgba(79, 79, 79,0.0)",
    elevation:9

  }
};